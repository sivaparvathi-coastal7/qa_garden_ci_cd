from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
import uvicorn
import subprocess
import json
import os
from pathlib import Path
from typing import Dict, List, Optional
import logging
from datetime import datetime
import requests
from bs4 import BeautifulSoup
from dotenv import load_dotenv
load_dotenv()


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="QA Garden UI/UX Test Automation API",
    description="API for managing Playwright test automation, test generation, and artifact management",
    version="1.0.0"
)

# Project pathsvw
PROJECT_ROOT = Path(__file__).resolve().parent
TESTS_DIR = PROJECT_ROOT / "tests"
ARTIFACTS_DIR = PROJECT_ROOT / "artifacts"
SCREENSHOTS_DIR = ARTIFACTS_DIR / "screenshots"
VIDEOS_DIR = ARTIFACTS_DIR / "videos"
TEST_LOGS_DIR = ARTIFACTS_DIR / "logs"
TRACES_DIR = ARTIFACTS_DIR / "traces"
TESTCASES_DIR = PROJECT_ROOT / "testcases"
CONFIG_DIR = PROJECT_ROOT / "config"

# Create artifacts directory if it doesn't exist
ARTIFACTS_DIR.mkdir(exist_ok=True)
SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)
VIDEOS_DIR.mkdir(parents=True, exist_ok=True)
TEST_LOGS_DIR.mkdir(parents=True, exist_ok=True)
TRACES_DIR.mkdir(parents=True, exist_ok=True)

JIRA_EMAIL = os.getenv("JIRA_EMAIL")
JIRA_API_TOKEN = os.getenv("JIRA_API_TOKEN")
JIRA_BASE_URL = os.getenv("JIRA_BASE_URL")
PROJECT_KEY = os.getenv("JIRA_PROJECT_KEY")

# Mount static files for serving artifacts
app.mount("/screenshots", StaticFiles(directory=str(SCREENSHOTS_DIR)), name="screenshots")
app.mount("/videos", StaticFiles(directory=str(VIDEOS_DIR)), name="videos")
app.mount("/logs", StaticFiles(directory=str(TEST_LOGS_DIR)), name="logs")

@app.get("/")
async def root():
    return {
        "message": "QA Garden UI/UX Test Automation API",
        "version": "1.0.0",
        "endpoints": {
            "health": "/health",
            "test_execution": "/tests/run/{page_type}",
            "test_generation": "/generate/tests",
            "artifacts": "/artifacts/{page_type}",
            "test_cases": "/testcases/{page_type}",
            "test_results": "/results/{page_type}",
            "locators_fetch": "/locators/fetch",
            "locators_save": "/locators/save-direct",
            "jira_update": "/jira/update-from-html/{page_type}"
        }
    }

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "project_root": str(PROJECT_ROOT)
    }

@app.get("/testcases")
def get_testcases():
    # DEBUG: Log environment variables
    logger.info(f"DEBUG - JIRA_EMAIL: {JIRA_EMAIL}")
    logger.info(f"DEBUG - JIRA_API_TOKEN: {JIRA_API_TOKEN[:20]}..." if JIRA_API_TOKEN else "DEBUG - JIRA_API_TOKEN: None")
    logger.info(f"DEBUG - JIRA_BASE_URL: {JIRA_BASE_URL}")
    logger.info(f"DEBUG - PROJECT_KEY: {PROJECT_KEY}")
    
    if not all([JIRA_EMAIL, JIRA_API_TOKEN, JIRA_BASE_URL, PROJECT_KEY]):
        logger.error("DEBUG - Missing JIRA configuration")
        raise HTTPException(status_code=500, detail="Jira configuration missing")

    url = f"{JIRA_BASE_URL}/rest/api/3/search/jql"
    logger.info(f"DEBUG - Full API URL: {url}")


    jql = f'project = {PROJECT_KEY}'
    logger.info(f"DEBUG - JQL Query: {jql}")

    try:
        logger.info("DEBUG - Making request to JIRA API...")
        response = requests.get(
          url,
          auth=(JIRA_EMAIL, JIRA_API_TOKEN),
          headers={"Accept": "application/json"},
          params={
            "jql": jql,
            "maxResults": 100,
            "fields": "key,summary,status,description"
          },
          timeout=10
        ) 
        
        logger.info(f"DEBUG - Response Status Code: {response.status_code}")
        logger.info(f"DEBUG - Response Headers: {dict(response.headers)}")
        
        if response.status_code != 200:
            logger.error(f"DEBUG - Response Text: {response.text}")
        
        response.raise_for_status()
        data = response.json()
        logger.info(f"DEBUG - Raw response data: {json.dumps(data, indent=2)[:500]}...")
        logger.info(f"DEBUG - Found {len(data.get('issues', []))} issues")

    except requests.exceptions.RequestException as e:
        logger.error(f"DEBUG - Jira API error: {e}")
        logger.error(f"DEBUG - Error type: {type(e).__name__}")
        raise HTTPException(status_code=500, detail="Failed to fetch testcases from Jira")

    results = []
    for issue in data.get("issues", []):
        fields = issue.get("fields", {})
        
        # Extract description text from complex object
        description = ""
        if fields.get("description") and isinstance(fields["description"], dict):
            content = fields["description"].get("content", [])
            for item in content:
                if item.get("type") == "paragraph":
                    for text_item in item.get("content", []):
                        if text_item.get("type") == "text":
                            description += text_item.get("text", "")

        results.append({
            "key": issue.get("key"),
            "summary": fields.get("summary"),
            "status": fields.get("status", {}).get("name") if fields.get("status") else "Unknown",
            "description": description or fields.get("description")
        })

    logger.info(f"DEBUG - Returning {len(results)} test cases")
    return {
        "count": len(results),
        "tests": results
    }




@app.post("/tests/run/{page_type}")
async def run_tests(page_type: str, background_tasks: BackgroundTasks):
    """Run Playwright tests for specific page type (login, signup, welcome)"""
    valid_pages = ["login", "signup", "welcome"]
    if page_type not in valid_pages:
        raise HTTPException(status_code=400, detail=f"Invalid page type. Must be one of: {valid_pages}")
    
    test_path = TESTS_DIR / page_type / f"test_{page_type}.py"
    if not test_path.exists():
        raise HTTPException(status_code=404, detail=f"Test file not found: {test_path}")
    
    try:
        # Run pytest for specific page type
        cmd = ["python", "-m", "pytest", str(test_path), "-v", "--tb=short"]
        result = subprocess.run(cmd, cwd=PROJECT_ROOT, capture_output=True, text=True, timeout=300)
        
        return {
            "status": "completed",
            "page_type": page_type,
            "exit_code": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "artifacts_available": f"/artifacts/{page_type}"
        }
    except subprocess.TimeoutExpired:
        return {"status": "timeout", "message": "Test execution timed out after 5 minutes"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Test execution failed: {str(e)}")

@app.post("/generate/tests")
async def generate_tests():
    """Generate test files using the LLM-based test generation script"""
    try:
        cmd = ["python", "generate_script.py"]
        result = subprocess.run(cmd, cwd=PROJECT_ROOT, capture_output=True, text=True, timeout=120)
        
        return {
            "status": "completed",
            "exit_code": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "message": "Test generation completed"
        }
    except subprocess.TimeoutExpired:
        return {"status": "timeout", "message": "Test generation timed out after 2 minutes"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Test generation failed: {str(e)}")

@app.get("/artifacts/{page_type}")
async def get_artifacts(page_type: str):
    """Get available artifacts (screenshots, videos, logs) for a page type"""
    valid_pages = ["login", "signup", "welcome"]
    if page_type not in valid_pages:
        raise HTTPException(status_code=400, detail=f"Invalid page type. Must be one of: {valid_pages}")
    
    artifacts = {
        "page_type": page_type,
        "screenshots": [],
        "videos": [],
        "logs": []
    }
    
    # Get screenshots
    screenshots_path = SCREENSHOTS_DIR / page_type
    if screenshots_path.exists():
        artifacts["screenshots"] = [f.name for f in screenshots_path.glob("*.png")]
    
    # Get videos
    videos_path = VIDEOS_DIR / page_type
    if videos_path.exists():
        artifacts["videos"] = [f.name for f in videos_path.glob("*.webm")]
    
    # Get logs
    logs_path = TEST_LOGS_DIR / page_type
    if logs_path.exists():
        artifacts["logs"] = [f.name for f in logs_path.glob("*.log")]
    
    return artifacts


@app.get("/results/{page_type}")
async def get_test_results(page_type: str):
    """Get test execution results summary for a page type"""
    valid_pages = ["login", "signup", "welcome"]
    if page_type not in valid_pages:
        raise HTTPException(status_code=400, detail=f"Invalid page type. Must be one of: {valid_pages}")
    
    logs_path = TEST_LOGS_DIR / page_type
    if not logs_path.exists():
        return {"page_type": page_type, "message": "No test results found"}
    
    results = {
        "page_type": page_type,
        "total_tests": 0,
        "passed": 0,
        "failed": 0,
        "test_details": []
    }
    
    # Parse log files for test results
    for log_file in logs_path.glob("*.log"):
        test_name = log_file.stem
        try:
            with open(log_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Extract test result from log
            if "✅ PASSED" in content:
                status = "PASSED"
                results["passed"] += 1
            elif "❌ FAILED" in content:
                status = "FAILED"
                results["failed"] += 1
            else:
                status = "UNKNOWN"
            
            # Extract duration
            duration = "N/A"
            for line in content.split('\n'):
                if "PASSED -" in line or "FAILED -" in line:
                    parts = line.split(' - ')
                    if len(parts) > 1:
                        duration = parts[1].split(' - ')[0]
                    break
            
            results["test_details"].append({
                "test_name": test_name,
                "status": status,
                "duration": duration,
                "log_file": f"/logs/{page_type}/{log_file.name}"
            })
            results["total_tests"] += 1
            
        except Exception as e:
            logger.error(f"Error parsing log file {log_file}: {e}")
    
    return results

@app.post("/jira/update-from-html/{page_type}")
async def update_jira_from_html_report(page_type: str):
    """Update JIRA from existing HTML report"""
    reports_dir = ARTIFACTS_DIR / "reports"
    html_report = reports_dir / f"{page_type}_report.html"
    
    if not html_report.exists():
        raise HTTPException(status_code=404, detail=f"HTML report not found: {html_report}")
    
    try:
        # Parse HTML report
        with open(html_report, 'r', encoding='utf-8') as f:
            soup = BeautifulSoup(f.read(), 'html.parser')
        
        # Extract test results from HTML
        test_results = parse_html_report(soup)
        
        # Update JIRA for each test
        updated_results = []
        for test_result in test_results:
            jira_key = map_test_to_jira(test_result['name'])
            if jira_key == "SKIP":
                continue
                
            result = await update_jira_status(jira_key, test_result['status'])
            result['test_name'] = test_result['name']
            updated_results.append(result)
        
        return {
            "page_type": page_type,
            "html_report": str(html_report),
            "total_tests": len(test_results),
            "jira_updates": len(updated_results),
            "results": updated_results
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to parse HTML report: {str(e)}")

def parse_html_report(soup):
    """Extract test results from pytest HTML report"""
    results = []
    
    # Find test results table
    results_table = soup.find('table', {'id': 'results-table'})
    if not results_table:
        return results
    
    # Parse each test row
    for row in results_table.find('tbody').find_all('tr'):
        cells = row.find_all('td')
        if len(cells) >= 2:
            test_name = cells[0].get_text().strip()
            status_cell = cells[1]
            
            # Extract status from class or text
            if 'passed' in status_cell.get('class', []):
                status = 'PASSED'
            elif 'failed' in status_cell.get('class', []):
                status = 'FAILED'
            else:
                status = 'UNKNOWN'
            
            # Clean test name (remove file path)
            if '::' in test_name:
                test_name = test_name.split('::')[-1]
            
            results.append({
                'name': test_name,
                'status': status
            })
    
    return results

def map_test_to_jira(test_name: str) -> str:
    """Map test names to JIRA keys"""
    mapping = {
        "test_login_page_elements_visibility": "TC-LOGIN-001",
        "test_successful_login": "TC-LOGIN-002",
        "test_invalid_credentials_login": "TC-LOGIN-003",
        "test_empty_email_login": "TC-LOGIN-004",
        "test_empty_password_login": "TC-LOGIN-005",
        "test_invalid_email_format_login": "TC-LOGIN-006",
        "test_show_password_toggle": "TC-LOGIN-007",
        "test_navigate_to_signup_page": "TC-LOGIN-008",
        "test_forgot_password_link_opens_modal": "TC-LOGIN-009",
        "test_sign_in_with_google_button": "TC-LOGIN-010",
        # Add signup mappings
        "test_sign_up_page_elements_visibility": "TC-SIGNUP-001",
        "test_successful_sign_up": "TC-SIGNUP-002",
        # Add more mappings as needed
    }
    return mapping.get(test_name, "SKIP")

@app.post("/jira/update-status/{issue_key}")
async def update_jira_status(issue_key: str, status: str):
    """Update JIRA issue status"""
    if not all([JIRA_EMAIL, JIRA_API_TOKEN, JIRA_BASE_URL]):
        raise HTTPException(status_code=500, detail="JIRA config missing")
    
    jira_status = "Done" if status == "PASSED" else "To Do"
    
    try:
        url = f"{JIRA_BASE_URL}/rest/api/3/issue/{issue_key}/transitions"
        
        response = requests.get(url, auth=(JIRA_EMAIL, JIRA_API_TOKEN))
        transitions = response.json().get("transitions", [])
        
        transition_id = None
        for t in transitions:
            if t["to"]["name"] == jira_status:
                transition_id = t["id"]
                break
        
        if not transition_id:
            return {"status": "skipped", "issue_key": issue_key}
        
        payload = {"transition": {"id": transition_id}}
        response = requests.post(url, auth=(JIRA_EMAIL, JIRA_API_TOKEN), json=payload)
        response.raise_for_status()
        
        return {"status": "success", "issue_key": issue_key, "updated_to": jira_status}
        
    except Exception as e:
        return {"status": "error", "issue_key": issue_key, "error": str(e)}

@app.get("/download/screenshot/{page_type}/{filename}")
async def download_screenshot(page_type: str, filename: str):
    """Download a specific screenshot"""
    file_path = SCREENSHOTS_DIR / page_type / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Screenshot not found")
    return FileResponse(file_path)

@app.get("/download/video/{page_type}/{filename}")
async def download_video(page_type: str, filename: str):
    """Download a specific video"""
    file_path = VIDEOS_DIR / page_type / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Video not found")
    return FileResponse(file_path)

@app.get("/download/log/{page_type}/{filename}")
async def download_log(page_type: str, filename: str):
    """Download a specific log file"""
    file_path = TEST_LOGS_DIR / page_type / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Log file not found")
    return FileResponse(file_path)

@app.get("/config/locators/{page_type}")
async def get_locators(page_type: str):
    """Get locator configuration for a page type"""
    valid_pages = ["login", "signup", "welcome"]
    if page_type not in valid_pages:
        raise HTTPException(status_code=400, detail=f"Invalid page type. Must be one of: {valid_pages}")
    
    locator_file = CONFIG_DIR / f"{page_type}_locators.py"
    if not locator_file.exists():
        raise HTTPException(status_code=404, detail=f"Locators file not found: {locator_file}")
    
    try:
        with open(locator_file, 'r', encoding='utf-8') as f:
            content = f.read()
        return {"page_type": page_type, "locators": content}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read locators: {str(e)}")

@app.post("/locators/fetch")
async def fetch_and_save_locators(api_url: str, page_type: str):
    """Fetch locators from API and save to config folder"""
    try:
        response = requests.get(api_url)
        response.raise_for_status()
        
        data = response.json()
        locators_content = data.get("locators", "")
        
        # Save to config folder
        file_path = CONFIG_DIR / f"{page_type}_locators.py"
        with open(file_path, 'w') as f:
            f.write(locators_content)
        
        return {
            "status": "saved",
            "file": str(file_path),
            "page_type": page_type
        }
        
    except Exception as e:
        return {"status": "failed", "error": str(e)}

@app.post("/locators/save-direct")
async def save_locators_direct(page_type: str, locators_content: str):
    """Save locators content directly to file"""
    try:
        file_path = CONFIG_DIR / f"{page_type}_locators.py"
        with open(file_path, 'w') as f:
            f.write(locators_content)
        
        return {"status": "saved", "file": str(file_path)}
        
    except Exception as e:
        return {"status": "failed", "error": str(e)}

@app.delete("/artifacts/{page_type}")
async def clean_artifacts(page_type: str):
    """Clean artifacts for a specific page type"""
    valid_pages = ["login", "signup", "welcome", "all"]
    if page_type not in valid_pages:
        raise HTTPException(status_code=400, detail=f"Invalid page type. Must be one of: {valid_pages}")
    
    cleaned = {"screenshots": 0, "videos": 0, "logs": 0}
    
    if page_type == "all":
        pages_to_clean = ["login", "signup", "welcome"]
    else:
        pages_to_clean = [page_type]
    
    try:
        for page in pages_to_clean:
            # Clean screenshots
            screenshots_path = SCREENSHOTS_DIR / page
            if screenshots_path.exists():
                for f in screenshots_path.glob("*.png"):
                    f.unlink()
                    cleaned["screenshots"] += 1
            
            # Clean videosp
            videos_path = VIDEOS_DIR / page
            if videos_path.exists():
                for f in videos_path.glob("*.webm"):
                    f.unlink()
                    cleaned["videos"] += 1
            
            # Clean logs
            logs_path = TEST_LOGS_DIR / page
            if logs_path.exists():
                for f in logs_path.glob("*.log"):
                    f.unlink()
                    cleaned["logs"] += 1
        
        return {
            "status": "completed",
            "page_type": page_type,
            "cleaned": cleaned
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to clean artifacts: {str(e)}")

if __name__ == "__main__":
    uvicorn.run(app, host="192.168.1.40", port=8002)